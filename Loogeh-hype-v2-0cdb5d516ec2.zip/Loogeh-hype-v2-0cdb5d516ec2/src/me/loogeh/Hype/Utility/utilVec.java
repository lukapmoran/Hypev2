package me.loogeh.Hype.Utility;

import org.bukkit.Location;
import org.bukkit.util.Vector;

public class utilVec {
	
	public static Vector launch(Location from, Location to) {
		return null;
	}
	
	public static Vector launch() {
		return null;
	}

}

package me.loogeh.Hype.Games;

public class GameException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public GameException(String message) {
		super(message);
	}

}

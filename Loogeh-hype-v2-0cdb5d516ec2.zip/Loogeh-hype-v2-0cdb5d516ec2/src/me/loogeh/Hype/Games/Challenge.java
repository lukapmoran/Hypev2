package me.loogeh.Hype.Games;

public class Challenge {

}

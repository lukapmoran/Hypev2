package me.loogeh.Hype.Games;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public class ArcticBrawl extends Game {

	public ArcticBrawl(Map map, GameType type, Location lobby_loc) {
		super(map, type, lobby_loc);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void join(Player player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leave(Player player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lose(Player player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}
}

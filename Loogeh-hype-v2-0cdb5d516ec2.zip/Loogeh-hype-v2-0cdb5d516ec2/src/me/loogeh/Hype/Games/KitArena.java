package me.loogeh.Hype.Games;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public class KitArena extends Game {
	
	public KitArena(Map map, Location lobby_loc) {
		super(map, GameType.KIT_ARENA, lobby_loc);
	}

	@Override
	public void join(Player player) {
		
	}

	@Override
	public void leave(Player player) {
		
	}

	@Override
	public void lose(Player player) {
		
	}

	@Override
	public void start() {
		
	}

	@Override
	public void end() {
		
	}


}

package me.loogeh.Hype.Games;

public class Objective {

	public Objective() {
		
	}
	
	public enum ObjectiveType {
		CTF_FLAG,
		SABOTAGE_BOMB;
	}

	
}

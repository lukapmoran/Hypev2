package me.loogeh.Hype.Formatting;

import org.bukkit.ChatColor;

public class C {
	
	public static final char COLOR_CHAR = '\u00A7';
	
	public static String boldAqua = ChatColor.AQUA + ChatColor.BOLD.toString();
	public static String boldBlack = ChatColor.BLACK + ChatColor.BOLD.toString();
	public static String boldBlue = ChatColor.BLUE + ChatColor.BOLD.toString();
	public static String boldDarkAqua = ChatColor.DARK_AQUA + ChatColor.BOLD.toString();
	public static String boldDarkBlue = ChatColor.DARK_BLUE + ChatColor.BOLD.toString();
	public static String boldDarkGray = ChatColor.DARK_GRAY + ChatColor.BOLD.toString();
	public static String boldDarkGreen = ChatColor.DARK_GREEN + ChatColor.BOLD.toString();
	public static String boldDarkPurple = ChatColor.DARK_PURPLE + ChatColor.BOLD.toString();
	public static String boldDarkRed = ChatColor.DARK_RED + ChatColor.BOLD.toString();
	public static String boldGold = ChatColor.GOLD + ChatColor.BOLD.toString();
	public static String boldGray = ChatColor.GRAY + ChatColor.BOLD.toString();
	public static String boldGreen = ChatColor.GREEN + ChatColor.BOLD.toString();
	public static String boldItalic = ChatColor.ITALIC + ChatColor.BOLD.toString();
	public static String boldLightPurple = ChatColor.LIGHT_PURPLE + ChatColor.BOLD.toString();
	public static String boldMagic = ChatColor.MAGIC + ChatColor.BOLD.toString();
	public static String boldRed = ChatColor.RED + ChatColor.BOLD.toString();
	public static String boldReset = ChatColor.RESET + ChatColor.BOLD.toString();
	public static String boldStrikethrough = ChatColor.STRIKETHROUGH + ChatColor.BOLD.toString();
	public static String boldUnderline = ChatColor.UNDERLINE + ChatColor.BOLD.toString();
	public static String boldYellow = ChatColor.YELLOW + ChatColor.BOLD.toString();
	
	
	public static String underlineAqua = ChatColor.AQUA + ChatColor.UNDERLINE.toString();
	public static String underlineBlack = ChatColor.BLACK + ChatColor.UNDERLINE.toString();
	public static String underlineBlue = ChatColor.BLUE + ChatColor.UNDERLINE.toString();
	public static String underlineDarkAqua = ChatColor.DARK_AQUA + ChatColor.UNDERLINE.toString();
	public static String underlineDarkBlue = ChatColor.DARK_BLUE + ChatColor.UNDERLINE.toString();
	public static String underlineDarkGray = ChatColor.DARK_GRAY + ChatColor.UNDERLINE.toString();
	public static String underlineDarkGreen = ChatColor.DARK_GREEN + ChatColor.UNDERLINE.toString();
	public static String underlineDarkPurple = ChatColor.DARK_PURPLE + ChatColor.UNDERLINE.toString();
	public static String underlineDarkRed = ChatColor.DARK_RED + ChatColor.UNDERLINE.toString();
	public static String underlineGold = ChatColor.GOLD + ChatColor.UNDERLINE.toString();
	public static String underlineGray = ChatColor.GRAY + ChatColor.UNDERLINE.toString();
	public static String underlineGreen = ChatColor.GREEN + ChatColor.UNDERLINE.toString();
	public static String underlineItalic = ChatColor.ITALIC + ChatColor.UNDERLINE.toString();
	public static String underlineLightPurple = ChatColor.LIGHT_PURPLE + ChatColor.UNDERLINE.toString();
	public static String underlineMagic = ChatColor.MAGIC + ChatColor.UNDERLINE.toString();
	public static String underlineRed = ChatColor.RED + ChatColor.UNDERLINE.toString();
	public static String underlineReset = ChatColor.RESET + ChatColor.UNDERLINE.toString();
	public static String underlineStrikethrough = ChatColor.STRIKETHROUGH + ChatColor.UNDERLINE.toString();
	public static String underlineUnderline = ChatColor.UNDERLINE + ChatColor.UNDERLINE.toString();
	public static String underlineYellow = ChatColor.YELLOW + ChatColor.UNDERLINE.toString();
	
	public static String Aqua = ChatColor.AQUA.toString();
	public static String Black = ChatColor.BLACK.toString();
	public static String Blue = ChatColor.BLUE.toString();
	public static String DarkAqua = ChatColor.DARK_AQUA.toString();
	public static String DarkBlue = ChatColor.DARK_BLUE.toString();
	public static String DarkGray = ChatColor.DARK_GRAY.toString();
	public static String DarkGreen = ChatColor.DARK_GREEN.toString();
	public static String DarkPurple = ChatColor.DARK_PURPLE.toString();
	public static String DarkRed = ChatColor.DARK_RED.toString();
	public static String Gold = ChatColor.GOLD.toString();
	public static String Gray = ChatColor.GRAY.toString();
	public static String Green = ChatColor.GREEN.toString();
	public static String Italic = ChatColor.ITALIC.toString();
	public static String LightPurple = ChatColor.LIGHT_PURPLE.toString();
	public static String Magic = ChatColor.MAGIC.toString();
	public static String Red = ChatColor.RED.toString();
	public static String Reset = ChatColor.RESET.toString();
	public static String Strikethrough = ChatColor.STRIKETHROUGH.toString();
	public static String Underline = ChatColor.UNDERLINE.toString();
	public static String Yellow = ChatColor.YELLOW.toString();
	
	
	
	

}

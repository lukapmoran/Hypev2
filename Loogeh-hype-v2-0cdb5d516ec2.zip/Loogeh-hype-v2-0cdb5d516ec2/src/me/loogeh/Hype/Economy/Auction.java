package me.loogeh.Hype.Economy;

public class Auction {

}

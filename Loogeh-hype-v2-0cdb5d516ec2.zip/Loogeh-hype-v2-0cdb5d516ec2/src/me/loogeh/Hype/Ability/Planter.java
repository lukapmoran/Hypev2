package me.loogeh.Hype.Ability;

import me.loogeh.Hype.Armour.Ability;
import me.loogeh.Hype.Armour.AbilityInfo;

public class Planter extends Ability {

	public Planter() {
		super("Planter", AbilityInfo.PLANTER);
	}

}

package me.loogeh.Hype.Ability;

public class Soothe {
	/*Soothe doesn't need a class beacuse it
	 * is handled within the P.java file. This
	 * class is just here to remind me*/
}

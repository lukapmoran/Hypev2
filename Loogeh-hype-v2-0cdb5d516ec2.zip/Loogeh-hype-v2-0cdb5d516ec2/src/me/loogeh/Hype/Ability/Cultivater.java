package me.loogeh.Hype.Ability;

import me.loogeh.Hype.Armour.Ability;
import me.loogeh.Hype.Armour.AbilityInfo;

public class Cultivater extends Ability {

	public Cultivater() {
		super("Cultivater", AbilityInfo.CULTIVATER);
	}

}

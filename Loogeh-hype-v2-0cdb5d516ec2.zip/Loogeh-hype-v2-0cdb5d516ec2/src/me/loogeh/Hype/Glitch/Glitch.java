package me.loogeh.Hype.Glitch;

public class Glitch {

}

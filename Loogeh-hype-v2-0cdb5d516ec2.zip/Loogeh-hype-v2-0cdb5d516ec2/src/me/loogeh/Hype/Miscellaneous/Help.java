package me.loogeh.Hype.Miscellaneous;

import java.util.HashMap;

import org.bukkit.entity.Player;

import me.loogeh.Hype.Moderation.Permissions.Ranks;

public class Help {
	
	public static HashMap<String, Ranks> generateHelpMenu(Player player) {
		return null;
	}

}

package me.loogeh.Hype.Event;

public class GameEvent {

}

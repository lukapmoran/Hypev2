package me.loogeh.Hype.Trading;

public class TradeInventory {

//	public TradeInventory(Player player, Player target) {
//		super(ChatColor.DARK_GREEN + player.getName() + "             " + target.getName(), 27);
//	}
}

package me.loogeh.Hype.Fields;

public class OreField {

}
